
document.getElementById('add-score').addEventListener('click', () => {
    const playerName = document.getElementById('player-name').value;
    const score = parseInt(document.getElementById('score').value);

    if (!playerName || isNaN(score)) {
        alert('Please enter a valid name and score.');
        return;
    }

    const scoreboard = document.getElementById('scoreboard');
    let row = document.createElement('tr');
    row.innerHTML = `<td>${playerName}</td><td>${score}</td>`;
    scoreboard.appendChild(row);

    document.getElementById('player-name').value = '';
    document.getElementById('score').value = '';
});

document.getElementById('reset-scores').addEventListener('click', () => {
    document.getElementById('scoreboard').innerHTML = '';
});
